# Serial Output Test as CSV

This is a simple basic test for any processor type

We just send a generated sine wave to the Serial Output
