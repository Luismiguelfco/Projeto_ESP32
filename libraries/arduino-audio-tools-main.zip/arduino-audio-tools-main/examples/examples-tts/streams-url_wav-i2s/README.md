
We generate generate a WAV from some text with the help of [rhasspy](https://rhasspy.readthedocs.io/en/latest/) which is running e.g. on a Rasperry Pi. 
and output the result via I2S.

Further details can be fond in https://www.pschatzmann.ch/home/2021/06/23/text-to-speach-in-arduino-conclusions/
