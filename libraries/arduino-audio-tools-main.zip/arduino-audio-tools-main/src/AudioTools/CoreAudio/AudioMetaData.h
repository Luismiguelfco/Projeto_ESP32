#pragma once
#include "AudioTools/CoreAudio/AudioMetaData/MetaData.h"
