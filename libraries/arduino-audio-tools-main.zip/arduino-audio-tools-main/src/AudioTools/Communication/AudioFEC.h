#pragma once
// Forward Error Corrections
#include "AudioTools/Communication/ReedSolomonFEC.h"
#include "AudioTools/Communication/HammingFEC.h"