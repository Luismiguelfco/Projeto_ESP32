var searchData=
[
  ['reconnect_106',['reconnect',['../class_bluetooth_a2_d_p_common.html#ac795a023f85438355a1b00644f2b040f',1,'BluetoothA2DPCommon']]],
  ['reconnectstatus_107',['ReconnectStatus',['../group__a2dp.html#ga28a6ac1cbaf47c9d341da5391e2e72b3',1,'BluetoothA2DPCommon.h']]],
  ['reset_5flast_5fconnection_108',['reset_last_connection',['../class_bluetooth_a2_d_p_source.html#a190c59464f53e2d4c3f121afbb7a3c21',1,'BluetoothA2DPSource']]],
  ['rewind_109',['rewind',['../class_bluetooth_a2_d_p_sink.html#a9ee01e6d11ee3c6c546a510029a23a12',1,'BluetoothA2DPSink']]]
];
