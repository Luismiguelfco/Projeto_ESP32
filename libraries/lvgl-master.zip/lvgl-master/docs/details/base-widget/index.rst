.. _base_widget_overview:

===========
Base Widget
===========

The following details apply to all types of Widgets.

.. toctree::
    :maxdepth:  3

    obj
    coord
    layer
    styles/index
    event
    layouts/index
    scroll
