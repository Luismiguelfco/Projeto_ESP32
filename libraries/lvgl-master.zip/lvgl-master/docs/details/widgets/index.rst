.. _widgets:

=======
Widgets
=======

.. toctree::
    :maxdepth: 1

    animimg
    arc
    bar
    button
    buttonmatrix
    calendar
    canvas
    chart
    checkbox
    dropdown
    image
    imagebutton
    keyboard
    label
    led
    line
    list
    lottie
    menu
    msgbox
    roller
    scale
    slider
    spangroup
    spinbox
    spinner
    switch
    table
    tabview
    textarea
    tileview
    win
    new_widget
