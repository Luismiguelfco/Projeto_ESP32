=================
Software Renderer
=================

API
***

:ref:`lv_draw_sw_h`

:ref:`lv_draw_sw_blend_h`

:ref:`lv_draw_sw_gradient_h`
