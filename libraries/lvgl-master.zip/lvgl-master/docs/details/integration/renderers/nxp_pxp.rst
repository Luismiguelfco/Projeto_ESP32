===========
NXP PXP GPU
===========

API
***

:ref:`lv_draw_pxp_h`

:ref:`lv_pxp_cfg_h`

:ref:`lv_pxp_osa_h`

:ref:`lv_pxp_utils_h`

