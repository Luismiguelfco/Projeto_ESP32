.. _main_components:

===============
Main Components
===============

.. toctree::
    :maxdepth: 2

    display
    indev
    color
    font
    image
    timer
    animation
    fs
    draw
