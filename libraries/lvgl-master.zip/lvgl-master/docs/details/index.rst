.. _reference:

=========
Reference
=========

.. toctree::
    :maxdepth: 2

    base-widget/index
    widgets/index
    main-components/index
    other-components/index
    ../examples
    debugging/index
    integration/index
    libs/index
