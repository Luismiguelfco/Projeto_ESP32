
python3.10 ../../../scripts/LVGLImage.py $1 --ofmt C -o ../src/generated --cf $2
